#!/bin/bash -x

init() {
    # Ref: https://docs.aws.amazon.com/eks/latest/userguide/efs-csi.html
    kubectl apply -k "github.com/kubernetes-sigs/aws-efs-csi-driver/deploy/kubernetes/overlays/stable/?ref=master"
}


uninit() {
    # Ref: https://docs.aws.amazon.com/eks/latest/userguide/efs-csi.html
    kubectl delete -k "github.com/kubernetes-sigs/aws-efs-csi-driver/deploy/kubernetes/overlays/stable/?ref=master"
}

# PVC: partition from that HARDDISK

# deploy-efs-imgs-work-dir() {
#     STORAGE_NAME=imgs-work-dir
#     EFS_ID=fs-b08b8f33
#     helm upgrade --install dev-${STORAGE_NAME} efs \
#         --set storage.name="${STORAGE_NAME}" \
#         --set efs.id="${EFS_ID}" \
#         --set sc.name="efs-sc-${STORAGE_NAME}" \
#         --set pv.name="pv-${STORAGE_NAME}"
# }

# undeploy-efs-imgs-work-dir() {
#     STORAGE_NAME=imgs-work-dir
#     helm uninstall dev-${STORAGE_NAME}
# }

deploy-efs-package-analyzer-db() {
    STORAGE_NAME=package-analyzer-db
    EFS_ID=fs-6d4645ee
    helm upgrade --install dev-${STORAGE_NAME} efs \
        --set storage.name="${STORAGE_NAME}" \
        --set efs.id="${EFS_ID}" \
        --set sc.name="efs-sc-${STORAGE_NAME}" \
        --set pv.name="pv-${STORAGE_NAME}"
}

undeploy-efs-package-analyzer-db() {
    STORAGE_NAME=package-analyzer-db
    helm uninstall dev-${STORAGE_NAME}
}

deploy-efs-image-db() {
    STORAGE_NAME=image-db
    EFS_ID=fs-9a444719
    helm upgrade --install dev-${STORAGE_NAME} efs \
        --set storage.name="${STORAGE_NAME}" \
        --set efs.id="${EFS_ID}" \
        --set sc.name="efs-sc-${STORAGE_NAME}" \
        --set pv.name="pv-${STORAGE_NAME}"
}

undeploy-efs-image-db() {
    STORAGE_NAME=image-db
    helm uninstall dev-${STORAGE_NAME}
}

deploy() {
    # deploy-efs-imgs-work-dir
    deploy-efs-package-analyzer-db
    deploy-efs-image-db
}

undeploy() {
    # undeploy-efs-imgs-work-dir
    undeploy-efs-package-analyzer-db
    undeploy-efs-image-db
}

case "${@}"
in
    ("init") init ;;
    ("deploy") deploy ;;
    ("undeploy") undeploy ;;
    ("deploy-efs-imgs-work-dir") deploy-efs-imgs-work-dir ;;
    ("undeploy-efs-imgs-work-dir") undeploy-efs-imgs-work-dir ;;
    ("deploy-efs-package-analyzer-db") deploy-efs-package-analyzer-db ;;
    ("undeploy-efs-package-analyzer-db") undeploy-efs-package-analyzer-db ;;
    ("deploy-efs-image-db") deploy-efs-image-db ;;
    ("undeploy-efs-image-db") undeploy-efs-image-db ;;
    (*) echo "$0 [ init | deploy | undeploy ]" ;;
esac
