#!/bin/bash -ex

# Ref: https://docs.aws.amazon.com/eks/latest/userguide/efs-csi.html

#K8S_VERSION=$(kubectl version --client --short)
#K8S_VERSION=${K8S_VERSION#Client Version: v}
# VPC_ID
# VPC_ID=vpc-043c66c48c14931fc
# aws ec2 describe-vpcs --vpc-ids ${VPC_ID} --query "Vpcs[].CidrBlock" --output text
# Create security group
# Create EFS
# Apply efs CSI driver

kubectl apply -k "github.com/kubernetes-sigs/aws-efs-csi-driver/deploy/kubernetes/overlays/stable/?ref=master"
kubectl apply -f pv.yaml
kubectl apply -f claim.yaml
kubectl apply -f storageclass.yaml

